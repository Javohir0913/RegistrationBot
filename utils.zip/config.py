BPT_TOKEN = ""

DB_NAME = "registratiom.db"
